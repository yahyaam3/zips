<template>
  <footer class="bg-white border-t border-gray-200 mt-8">
    <div class="max-w-6xl mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between">
      <span class="text-gray-500 text-sm">&copy; {{ new Date().getFullYear() }} Skill2. Todos los derechos reservados.</span>
      <div class="flex space-x-4 mt-2 sm:mt-0">
        <a href="#" class="text-gray-400 hover:text-blue-600 transition-colors text-sm">Política de Privacidad</a>
        <a href="#" class="text-gray-400 hover:text-blue-600 transition-colors text-sm">Términos de Servicio</a>
        <a href="#" class="text-gray-400 hover:text-blue-600 transition-colors text-sm">Contacto</a>
      </div>
    </div>
  </footer>
</template>