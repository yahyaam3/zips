<template>
  <nav class="bg-blue-600 p-4 flex justify-between items-center">
    <div class="text-white font-bold text-xl">
      Skill2-2025
    </div>
    <ul class="flex space-x-4">
      <li>
        <a href="/" class="text-white hover:underline">Inicio</a>
      </li>
      <li>
        <a href="/Athlete" class="text-white hover:underline">Atletas</a>
      </li>
      <li>
        <a href="/sport" class="text-white hover:underline">Deportes</a>
      </li>
    </ul>
  </nav>
</template>

<script setup>
// No logic needed for este navbar básico
</script>