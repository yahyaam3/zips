<template>
  <footer class="w-full text-center py-4 bg-gray-800 text-white mt-auto">
    <div class="font-semibold text-lg">Alex &middot; Institut Cendrassos</div>
    <div class="text-sm text-gray-300">&copy; 2025</div>
  </footer>
</template>