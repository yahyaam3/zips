<template>
  <header class="flex justify-between items-center p-6 bg-white shadow">
    <div class="text-2xl font-bold text-gray-800">Mi Proyecto</div>
    <nav class="flex gap-4">
      <Link :href="route('home')" class="text-gray-600 hover:text-black">Inicio</Link>
      <Link :href="route('product.index')" class="text-gray-600 hover:text-black">Productos</Link>
      <Link :href="route('category.index')" class="text-gray-600 hover:text-black">Categoria</Link>
      <Link
        v-if="$page.props.auth?.user"
        :href="route('dashboard')"
        class="text-blue-600 hover:underline"
      >Dashboard</Link>
      <template v-else>
        <Link :href="route('login')" class="text-blue-600 hover:underline">Login</Link>
        <Link v-if="$page.props.canRegister" :href="route('register')" class="text-blue-600 hover:underline">Register</Link>
      </template>
    </nav>
  </header>
  <slot />
</template>

<script setup>
import { Link } from '@inertiajs/vue3';
</script>