<script setup>
import { Head, Link, router } from '@inertiajs/vue3';
import { ref, defineProps } from 'vue';
import axios from 'axios';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const props = defineProps({
    product: Object
});

// No products array needed here
</script>
<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-2xl mx-auto p-4">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Detalle de Producto</h1>
        <div class="overflow-x-auto rounded shadow bg-white mb-6">
          <table class="w-full text-left border border-gray-300" aria-label="Detalle de producto">
            <thead class="bg-gray-200">
              <tr>
                <th class="p-3 border-b border-gray-300">Nombre</th>
                <th class="p-3 border-b border-gray-300">Precio</th>
                <th class="p-3 border-b border-gray-300">Descripción</th>
                <th class="p-3 border-b border-gray-300">Categoría</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="p-3 border-b border-gray-200 text-gray-900">{{ product.name }}</td>
                <td class="p-3 border-b border-gray-200 text-gray-900">${{ product.price }}</td>
                <td class="p-3 border-b border-gray-200 text-gray-900">{{ product.description }}</td>
                <td class="p-3 border-b border-gray-200 text-gray-900">{{ product.category.name }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex flex-wrap gap-2">
          <Link :href="route('product.index')" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 focus:ring-2 focus:ring-gray-400" aria-label="Volver a productos">
            Volver
          </Link>
          <Link :href="route('product.create')" class="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800 focus:ring-2 focus:ring-green-400" aria-label="Crear nuevo producto">
            Crear Producto
          </Link>
        </div>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>