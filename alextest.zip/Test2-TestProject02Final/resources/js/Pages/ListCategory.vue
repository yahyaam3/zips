<script setup>
import { Head, Link } from '@inertiajs/vue3';
import { ref, defineProps, watch } from 'vue';
import axios from 'axios';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const props = defineProps({
    categories: Object // paginator object
});

const categories = ref(props.categories.data || []);
const pagination = ref({
    current_page: props.categories.current_page,
    last_page: props.categories.last_page,
    next_page_url: props.categories.next_page_url,
    prev_page_url: props.categories.prev_page_url,
    total: props.categories.total,
    per_page: props.categories.per_page,
});
const search = ref('');
const isDeleting = ref(false);

async function fetchCategories(page = 1) {
    try {
        const response = await axios.get(route('category.index'), {
            params: {
                search: search.value,
                page: page
            }
        });
        categories.value = response.data.categories.data;
        pagination.value = {
            current_page: response.data.categories.current_page,
            last_page: response.data.categories.last_page,
            next_page_url: response.data.categories.next_page_url,
            prev_page_url: response.data.categories.prev_page_url,
            total: response.data.categories.total,
            per_page: response.data.categories.per_page,
        };
    } catch (error) {
        // handle error
    }
}

watch(search, () => fetchCategories(1));

function goToPage(page) {
    fetchCategories(page);
}

// --- Dynamic delete with confirmation (host prompt) ---
async function deleteCategory(category) {
  if (!window.confirm(`¿Seguro que deseas eliminar la categoría "${category.name}"?`)) {
    return;
  }
  isDeleting.value = true;
  try {
    await axios.post(route('category.destroy', category.id), {
      _method: 'DELETE'
    });
    // Refetch current page to keep pagination correct
    fetchCategories(pagination.value.current_page);
  } catch (error) {
    console.error(`Error deleting category with ID ${category.id}:`, error);
  }
  isDeleting.value = false;
}

// --- Original Inertia delete (commented) ---
// function eliminar(id){
//     router.delete(route('category.destroy', id))
// }
</script>
<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-3xl w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Categorías</h1>
        <label for="search-category" class="block text-gray-800 font-semibold mb-1">Buscar categoría</label>
        <input
          id="search-category"
          type="text"
          v-model="search"
          placeholder="Buscar por nombre"
          class="w-full px-3 py-2 border border-gray-400 rounded mb-4 focus:ring-2 focus:ring-blue-600 focus:outline-none"
          aria-label="Buscar categorías"
        />
        <div class="overflow-x-auto rounded shadow bg-white">
          <table class="w-full text-left border border-gray-300 text-sm" aria-label="Tabla de categorías">
            <thead class="bg-gray-200">
              <tr>
                <th class="p-2 border-b border-gray-300">Nombre</th>
                <th class="p-2 border-b border-gray-300">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="category in categories" :key="category.id" class="hover:bg-gray-50 focus-within:bg-blue-50">
                <td class="p-2 border-b border-gray-200 text-gray-900">{{ category.name }}</td>
                <td class="p-2 border-b border-gray-200">
                  <div class="flex flex-wrap gap-1">
                    <Link
                      :href="route('category.show', category.id)"
                      class="px-2 py-1 rounded bg-blue-800 text-white hover:bg-blue-900 focus:ring-2 focus:ring-blue-400"
                      aria-label="Ver categoría"
                    >Ver</Link>
                    <Link
                      :href="route('category.edit', category.id)"
                      class="px-2 py-1 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400"
                      aria-label="Editar categoría"
                    >Editar</Link>
                    <button
                      @click="deleteCategory(category)"
                      :disabled="isDeleting"
                      class="px-2 py-1 rounded bg-red-700 text-white hover:bg-red-800 focus:ring-2 focus:ring-red-400"
                      aria-label="Eliminar categoría"
                      type="button"
                    >Eliminar</button>
                  </div>
                </td>
              </tr>
              <tr v-if="categories.length === 0">
                <td colspan="2" class="p-2 text-center text-gray-500">No hay categorías</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- Pagination controls -->
        <div class="flex justify-center items-center gap-2 mt-4">
          <button
            v-if="pagination.current_page > 1"
            @click="goToPage(pagination.current_page - 1)"
            class="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400"
          >Anterior</button>
          <span>Página {{ pagination.current_page }} de {{ pagination.last_page }}</span>
          <button
            v-if="pagination.current_page < pagination.last_page"
            @click="goToPage(pagination.current_page + 1)"
            class="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400"
          >Siguiente</button>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
          <Link :href="route('category.create')" class="px-4 py-2 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400" aria-label="Crear nueva categoría">
            Crear Categoría
          </Link>
          <Link :href="route('home')" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400" aria-label="Volver al inicio">
            Volver
          </Link>
        </div>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>