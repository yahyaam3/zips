<script setup>
import { Head, Link, router } from '@inertiajs/vue3';
import { ref, defineProps, computed } from 'vue';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const props = defineProps({
    products: Array
});

function eliminar(id){
    router.delete(route('product.destroy', id))
}

const search = ref('')
const filteredProducts = computed(() =>
  props.products.filter(product =>
    product.name.toLowerCase().includes(search.value.toLowerCase()) ||
    product.description.toLowerCase().includes(search.value.toLowerCase()) ||
    product.price.toString().toLowerCase().includes(search.value.toLowerCase()) ||
    (product.category && product.category.name &&
      product.category.name.toLowerCase().includes(search.value.toLowerCase()))
  )
);
</script>
<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-3xl w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Productos</h1>
        <label for="search-product" class="block text-gray-800 font-semibold mb-1">Buscar producto</label>
        <input
          id="search-product"
          type="text"
          v-model="search"
          placeholder="Buscar por nombre, descripción, precio o categoría"
          class="w-full px-3 py-2 border border-gray-400 rounded mb-4 focus:ring-2 focus:ring-blue-600 focus:outline-none"
          aria-label="Buscar productos"
        />
        <div class="overflow-x-auto rounded shadow bg-white">
          <table class="w-full text-left border border-gray-300 text-sm" aria-label="Tabla de productos">
            <thead class="bg-gray-200">
              <tr>
                <th class="p-2 border-b border-gray-300">Nombre</th>
                <th class="p-2 border-b border-gray-300">Precio</th>
                <th class="p-2 border-b border-gray-300">Descripción</th>
                <th class="p-2 border-b border-gray-300">Categoría</th>
                <th class="p-2 border-b border-gray-300">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="product in filteredProducts" :key="product.id" class="hover:bg-gray-50 focus-within:bg-blue-50">
                <td class="p-2 border-b border-gray-200 text-gray-900">{{ product.name }}</td>
                <td class="p-2 border-b border-gray-200 text-gray-900">${{ product.price }}</td>
                <td class="p-2 border-b border-gray-200 text-gray-900">{{ product.description }}</td>
                <td class="p-2 border-b border-gray-200 text-gray-900">{{ product.category?.name || 'Sin categoría' }}</td>
                <td class="p-2 border-b border-gray-200">
                  <div class="flex flex-wrap gap-1">
                    <Link
                      :href="route('product.show', product.id)"
                      class="px-2 py-1 rounded bg-blue-800 text-white hover:bg-blue-900 focus:ring-2 focus:ring-blue-400"
                      aria-label="Ver producto"
                    >Ver</Link>
                    <Link
                      :href="route('product.edit', product.id)"
                      class="px-2 py-1 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400"
                      aria-label="Editar producto"
                    >Editar</Link>
                    <button
                      @click="eliminar(product.id)"
                      class="px-2 py-1 rounded bg-red-700 text-white hover:bg-red-800 focus:ring-2 focus:ring-red-400"
                      aria-label="Eliminar producto"
                      type="button"
                    >Eliminar</button>
                  </div>
                </td>
              </tr>
              <tr v-if="filteredProducts.length === 0">
                <td colspan="5" class="p-2 text-center text-gray-500">No hay productos</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
          <Link :href="route('product.create')" class="px-4 py-2 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400" aria-label="Crear nuevo producto">
            Crear Producto
          </Link>
          <Link :href="route('home')" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400" aria-label="Volver al inicio">
            Volver
          </Link>
        </div>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>