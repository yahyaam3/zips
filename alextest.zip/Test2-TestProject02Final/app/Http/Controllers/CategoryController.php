<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Category::query();

        // If there is a search parameter, filter by name
        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Paginate results (5 per page)
        $categories = $query->orderBy('id', 'desc')->paginate(5);

        // If the request is AJAX (axios), return JSON
        if ($request->wantsJson()) {
            return response()->json(['categories' => $categories]);
        }

        // Otherwise, render the Inertia view
        return Inertia::render('ListCategory', [
            'categories' => $categories
        ]);
    }

    /*     public function index()
    {
        return Inertia::render('ListCategory',[
            'categories'=>Category::all()
        ]);
    } */

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('CreateCategory');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required | max:255',
        ]);

        Category::create($validate);
        return redirect()->route('category.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        return Inertia::render('ShowCategory', [
            'category' => $category
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        return Inertia::render('EditCategory', [
            'category' => $category
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category $category)
    {
        $validate = $request->validate([
            'name' => 'required | max:255',
        ]);

        $category->update($validate);
        return redirect()->route('category.index');
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return redirect()->route('category.index');
    }
}
