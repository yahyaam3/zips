<?php

namespace Database\Seeders;

use App\Models\Category;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/* remember to change name of seeder class */
class CategorySeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Category::insert([
            'name' => 'Test Categoria 1',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Test Categoria 2',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}