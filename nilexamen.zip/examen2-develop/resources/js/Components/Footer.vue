<template>
    <footer class="bg-gray-800 text-white py-4">
      <div class="text-center">
        <p>Nil Suñer Xarles - 2º DAW</p>
        <p>Institut Cendrassos</p>
      </div>
    </footer>
  </template>
  
  <style scoped>
  footer {
    /* position: fixed; */
    bottom: 0;
    width: 100%;
    left: 0;
    background-color: #252850;
    color: white;
    padding: 10px;
    text-align: center;
  }
  
  footer p {
    margin: 0;
  }
  </style>
  