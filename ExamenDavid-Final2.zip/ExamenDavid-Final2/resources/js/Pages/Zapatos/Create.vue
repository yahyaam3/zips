<template>
    <Head title="Crear Zapato" />
    
    <ZapatosLayout>
        <h1 style="text-align: center; color: green; font-size: 24px; margin-bottom: 20px;">Crear Nuevo Zapato</h1>
        
        <form @submit.prevent="submit" style="width: 80%; margin: 0 auto; background-color: #f9f9f9; padding: 20px; border: 1px solid #ddd;">
            <!-- Nombre -->
            <div style="margin-bottom: 15px;">
                <label for="nombre" style="display: block; margin-bottom: 5px; font-weight: bold;">Nombre:</label>
                <input id="nombre" v-model="form.nombre" type="text" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.nombre" style="color: red; margin-top: 5px;">{{ form.errors.nombre }}</div>
            </div>
            
            <!-- Marca -->
            <div style="margin-bottom: 15px;">
                <label for="marca" style="display: block; margin-bottom: 5px; font-weight: bold;">Marca:</label>
                <input id="marca" v-model="form.marca" type="text" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.marca" style="color: red; margin-top: 5px;">{{ form.errors.marca }}</div>
            </div>
            
            <!-- Categoría -->
            <div style="margin-bottom: 15px;">
                <label for="categoria" style="display: block; margin-bottom: 5px; font-weight: bold;">Categoría:</label>
                <select id="categoria" v-model="form.categoria_id" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required>
                    <option value="" disabled>Selecciona una categoría</option>
                    <option v-for="categoria in categorias" :key="categoria.id" :value="categoria.id">{{ categoria.nombre }}</option>
                </select>
                <div v-if="form.errors.categoria_id" style="color: red; margin-top: 5px;">{{ form.errors.categoria_id }}</div>
            </div>
            
            <!-- Talla -->
            <div style="margin-bottom: 15px;">
                <label for="talla" style="display: block; margin-bottom: 5px; font-weight: bold;">Talla:</label>
                <input id="talla" v-model="form.talla" type="text" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.talla" style="color: red; margin-top: 5px;">{{ form.errors.talla }}</div>
            </div>
            
            <!-- Color -->
            <div style="margin-bottom: 15px;">
                <label for="color" style="display: block; margin-bottom: 5px; font-weight: bold;">Color:</label>
                <input id="color" v-model="form.color" type="text" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.color" style="color: red; margin-top: 5px;">{{ form.errors.color }}</div>
            </div>
            
            <!-- Precio -->
            <div style="margin-bottom: 15px;">
                <label for="precio" style="display: block; margin-bottom: 5px; font-weight: bold;">Precio:</label>
                <input id="precio" v-model="form.precio" type="number" step="0.01" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.precio" style="color: red; margin-top: 5px;">{{ form.errors.precio }}</div>
            </div>
            
            <!-- Stock -->
            <div style="margin-bottom: 15px;">
                <label for="stock" style="display: block; margin-bottom: 5px; font-weight: bold;">Stock:</label>
                <input id="stock" v-model="form.stock" type="number" style="width: 100%; padding: 8px; border: 1px solid #ccc;" required />
                <div v-if="form.errors.stock" style="color: red; margin-top: 5px;">{{ form.errors.stock }}</div>
            </div>
            
            <div style="text-align: center; margin-top: 20px;">
                <Link :href="route('zapatos.index')" style="background-color: #767676; color: white; padding: 10px 15px; text-decoration: none; display: inline-block; margin-right: 10px;">
                    Cancelar
                </Link>
                <button type="submit" style="background-color: #008933; color: white; padding: 10px 15px; border: none; cursor: pointer;">
                    Guardar Zapato
                </button>
            </div>
        </form>
    </ZapatosLayout>
</template>

<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3';
import ZapatosLayout from '@/Layouts/ZapatosLayout.vue';

const props = defineProps({
    categorias: Array
});

const form = useForm({
    nombre: '',
    marca: '',
    talla: '',
    color: '',
    precio: '',
    stock: '',
    categoria_id: ''
});

const submit = () => {
    form.post(route('zapatos.store'));
};
</script> 